﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using PLTableauxCalculator.Formulas;
using PLTableauxCalculator.Tableaux;

namespace PLTableaux
{
    public partial class plTableauxForm : Form
    {
        public plTableauxForm()
        {
            InitializeComponent();
        }

        private void bProcess_Click(object sender, EventArgs e)
        {
            try
            {
                txtResults.Text = "";
                List<Formula> lf = new List<Formula>();
                FormulaBase.Clear();
                if (!string.IsNullOrEmpty(txtPremises.Text))
                {
                    StringReader sr = new StringReader(txtPremises.Text);
                    string f = sr.ReadLine();
                    while (!string.IsNullOrEmpty(f))
                    {
                        Formula fp = new Formula();
                        f = fp.Parse(f.Trim());
                        lf.Add(fp);
                        f = sr.ReadLine();
                    }
                }
                if (!string.IsNullOrEmpty(txtConclusion.Text))
                {
                    Formula fc = new Formula();
                    fc.Parse(txtConclusion.Text.Trim());
                    fc.Negate();
                    lf.Add(fc);
                }
                TableauxCalculator tcalc = new TableauxCalculator(lf);
                bool bt = tcalc.Calculate();
                List<string> m = tcalc.Models;
                string msg;
                if (string.IsNullOrEmpty(txtConclusion.Text))
                {
                    if (bt)
                    {
                        msg = "The system is unsatisfiable";
                        MessageBox.Show(msg);
                    }
                    else
                    {
                        msg = "The system is satisfiable\r\nModels:\r\n";
                        foreach (string s in m)
                        {
                            msg += s + "\r\n";
                        }
                        txtResults.Text = msg;
                    }
                }
                else
                {
                    if (bt)
                    {
                        if (lf.Count > 1)
                        {
                            msg = "The conclusion follows from the premises";
                        }
                        else
                        {
                            msg = "The conclusion is a tautology";
                        }
                        txtResults.Text = msg;
                    }
                    else
                    {
                        msg = "The conclusion doesn't follows from the premises\r\nCounterexamples:\r\n";
                        foreach (string s in m)
                        {
                            msg += s + "\r\n";
                        }
                        txtResults.Text = msg;
                    }
                }
                pbTableaux.Image = tcalc.DrawTableaux();
            }
            catch (BadSyntaxException bex)
            {
                MessageBox.Show("Bad Syntax: " + bex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtPremises_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case '!':
                    e.KeyChar = FormulaBase.csnot;
                    break;
                case '&':
                    e.KeyChar = FormulaBase.csand;
                    break;
                case '|':
                    e.KeyChar = FormulaBase.csor;
                    break;
                case '<':
                    e.KeyChar = FormulaBase.csimp;
                    break;
                case '>':
                    e.KeyChar = FormulaBase.csdimp;
                    break;
            }
        }
    }
}
