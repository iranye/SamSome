﻿namespace PLTableaux
{
    partial class plTableauxForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtPremises = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtConclusion = new System.Windows.Forms.TextBox();
            this.bProcess = new System.Windows.Forms.Button();
            this.gbTableaux = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pbTableaux = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtResults = new System.Windows.Forms.TextBox();
            this.gbTableaux.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTableaux)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Premises";
            // 
            // txtPremises
            // 
            this.txtPremises.AcceptsReturn = true;
            this.txtPremises.AcceptsTab = true;
            this.txtPremises.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPremises.Location = new System.Drawing.Point(16, 30);
            this.txtPremises.Multiline = true;
            this.txtPremises.Name = "txtPremises";
            this.txtPremises.Size = new System.Drawing.Size(482, 207);
            this.txtPremises.TabIndex = 1;
            this.txtPremises.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPremises_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Conclusion";
            // 
            // txtConclusion
            // 
            this.txtConclusion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConclusion.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConclusion.Location = new System.Drawing.Point(16, 256);
            this.txtConclusion.Name = "txtConclusion";
            this.txtConclusion.Size = new System.Drawing.Size(649, 26);
            this.txtConclusion.TabIndex = 3;
            this.txtConclusion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPremises_KeyPress);
            // 
            // bProcess
            // 
            this.bProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bProcess.Location = new System.Drawing.Point(675, 256);
            this.bProcess.Name = "bProcess";
            this.bProcess.Size = new System.Drawing.Size(75, 26);
            this.bProcess.TabIndex = 4;
            this.bProcess.Text = "Process";
            this.bProcess.UseVisualStyleBackColor = true;
            this.bProcess.Click += new System.EventHandler(this.bProcess_Click);
            // 
            // gbTableaux
            // 
            this.gbTableaux.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbTableaux.Controls.Add(this.panel1);
            this.gbTableaux.Location = new System.Drawing.Point(16, 287);
            this.gbTableaux.Name = "gbTableaux";
            this.gbTableaux.Size = new System.Drawing.Size(734, 156);
            this.gbTableaux.TabIndex = 5;
            this.gbTableaux.TabStop = false;
            this.gbTableaux.Text = "Tableaux";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pbTableaux);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(728, 137);
            this.panel1.TabIndex = 0;
            // 
            // pbTableaux
            // 
            this.pbTableaux.Location = new System.Drawing.Point(0, 0);
            this.pbTableaux.Name = "pbTableaux";
            this.pbTableaux.Size = new System.Drawing.Size(100, 50);
            this.pbTableaux.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbTableaux.TabIndex = 0;
            this.pbTableaux.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(505, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Results";
            // 
            // txtResults
            // 
            this.txtResults.AcceptsReturn = true;
            this.txtResults.AcceptsTab = true;
            this.txtResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResults.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResults.Location = new System.Drawing.Point(508, 30);
            this.txtResults.Multiline = true;
            this.txtResults.Name = "txtResults";
            this.txtResults.ReadOnly = true;
            this.txtResults.Size = new System.Drawing.Size(239, 207);
            this.txtResults.TabIndex = 7;
            // 
            // plTableauxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 455);
            this.Controls.Add(this.txtResults);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gbTableaux);
            this.Controls.Add(this.bProcess);
            this.Controls.Add(this.txtConclusion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPremises);
            this.Controls.Add(this.label1);
            this.Name = "plTableauxForm";
            this.Text = "Propositional Logic Tableaux";
            this.gbTableaux.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTableaux)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPremises;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtConclusion;
        private System.Windows.Forms.Button bProcess;
        private System.Windows.Forms.GroupBox gbTableaux;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbTableaux;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtResults;
    }
}

