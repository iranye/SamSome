﻿using System.Collections.Generic;
using System.Drawing;
using PLTableauxCalculator.Formulas;

namespace PLTableauxCalculator.Tableaux
{
    public enum StepResult
    {
        None, BranchClosed, NotAllowed
    }

    public struct FormulaOrigin
    {
        public int _fnumber;
        public int _onumber;

        public FormulaOrigin(int f, int o)
        {
            _fnumber = f;
            _onumber = o;
        }
    }
    public abstract class TableauxElementBase
    {
        protected TableauxElementBase _parent;
        protected static int _fcnt;

        public TableauxElementBase(TableauxElementBase parent, FormulaBase f)
        {
            _parent = parent;
        }

        public static void Initialize()
        {
            _fcnt = 1;
        }

        public abstract bool Closed { get; }
        public abstract List<string> Models(List<string> m);
        public abstract bool Contains(FormulaBase f);
        public abstract bool PerformStep();
        public abstract void ExecuteStep(FormulaBase f, int origin);
        public abstract StepResult WhatIf(FormulaBase f);
        public abstract void Draw(Graphics gr, Font f, RectangleF rb);
        public abstract RectangleF CalcRect(Graphics gr, Font f, RectangleF rb);
        protected string RemoveBrackets(string s)
        {
            if (s.StartsWith("("))
            {
                s = s.Substring(1);
            }
            if (s.EndsWith(")"))
            {
                s = s.Substring(0, s.Length - 1);
            }
            return s;
        }
        protected FormulaBase Negate(FormulaBase fn)
        {
            if (fn is Formula)
            {
                fn.Negate();
                if (fn.Operator == LogicOperator.None)
                {
                    fn = fn.Operand(1);
                }
            }
            else
            {
                fn = new Formula(fn, null, LogicOperator.Not);
            }
            return fn;
        }
    }
}
