﻿using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text.RegularExpressions;
using PLTableauxCalculator.Formulas;

namespace PLTableauxCalculator.Tableaux
{
    public class TableauxCalculator
    {
        private TableauxElementAlpha _root;

        public TableauxCalculator(List<Formula> premises)
        {
            TableauxElementBase.Initialize();
            _root = new TableauxElementAlpha(null, premises[0]);
            for (int ix = 1; ix < premises.Count; ix++)
            {
                _root.AddFormula(premises[ix]);
            }
        }

        public List<string> Models
        {
            get
            {
                List<string> m = new List<string>();
                m = Complete(_root.Models(m));
                for (int ix = m.Count - 1; ix > 0; ix--)
                {
                    if (Duplicated(m[ix], m, ix))
                    {
                        m.RemoveAt(ix);
                    }
                }
                return m;
            }
        }

        public bool Calculate()
        {
            while ((!_root.Closed) && (_root.PerformStep())) ;
            return _root.Closed;
        }

        public Bitmap DrawTableaux()
        {
            Bitmap bmp = new Bitmap(1, 1);
            Graphics gr = Graphics.FromImage(bmp);            
            Font f = new Font("Courier New", 20f, FontStyle.Regular, GraphicsUnit.Pixel);
            RectangleF rect = _root.CalcRect(gr, f, RectangleF.Empty);
            bmp = new Bitmap((int)rect.Width, (int)rect.Height);
            gr = Graphics.FromImage(bmp);
            gr.SmoothingMode = SmoothingMode.AntiAlias;
            gr.FillRectangle(Brushes.White, rect);
            _root.Draw(gr, f, rect);
            f.Dispose();
            return bmp;
        }

        private bool Duplicated(string s, List<string> l, int index)
        {
            string[] parts = s.Split(';');
            for (int ix = index - 1; ix >= 0; ix--)
            {
                string[] other = l[ix].Split(';');
                int c = 0;
                foreach (string sp in parts)
                {
                    if (other.Contains<string>(sp))
                    {
                        c++;
                    }
                }
                if (c == parts.Length)
                {
                    return true;
                }
            }
            return false;
        }

        private List<string> Complete(List<string> m)
        {
            for (int ix = 0; ix < m.Count; ix++)
            {
                string[] parts = m[ix].Split(';');
                if (parts.Length < FormulaBase.Predicates.Count)
                {
                    foreach (FormulaBase fp in FormulaBase.Predicates)
                    {
                        Regex rex = new Regex(fp.ToString() + "=[TF]");
                        if (!rex.IsMatch(m[ix]))
                        {
                            m[ix] += ";" + fp.ToString() + "=F";
                        }
                    }
                }
            }
            return m;
        }
    }
}
