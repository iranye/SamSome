﻿using System;
using System.Collections.Generic;
using System.Drawing;
using PLTableauxCalculator.Formulas;

namespace PLTableauxCalculator.Tableaux
{
    public class TableauxElementAlpha : TableauxElementBase
    {
        private List<KeyValuePair<FormulaOrigin, FormulaBase>> _formulas = new List<KeyValuePair<FormulaOrigin, FormulaBase>>();
        private KeyValuePair<int, TableauxElementBeta> _branch = new KeyValuePair<int, TableauxElementBeta>(-1, null);

        public TableauxElementAlpha(TableauxElementBase parent, FormulaBase f)
            : base(parent, f)
        {
            _formulas.Add(new KeyValuePair<FormulaOrigin, FormulaBase>(new FormulaOrigin(_fcnt++, -1), f));
        }
        public void AddFormula(Formula f)
        {
            _formulas.Add(new KeyValuePair<FormulaOrigin, FormulaBase>(new FormulaOrigin(_fcnt++, -1), f));
        }
        public override bool Closed
        {
            get
            {
                if (_branch.Value == null)
                {
                    foreach (KeyValuePair<FormulaOrigin, FormulaBase> fa in _formulas)
                    {
                        FormulaBase fn = Negate(fa.Value.Clone());
                        if (Contains(fn))
                        {
                            return true;
                        }
                    }
                    return false;
                }
                else
                {
                    return _branch.Value.Closed;
                }
            }
        }

        public override List<string> Models(List<string> m)
        {
            if (!Closed)
            {
                foreach (KeyValuePair<FormulaOrigin, FormulaBase> fa in _formulas)
                {
                    string val = "";
                    if (fa.Value is Formula)
                    {
                        Formula fm = fa.Value as Formula;
                        if (fm.Operator == LogicOperator.Not)
                        {
                            if (!(fm.Operand(1) is Formula))
                            {
                                val = fm.Operand(1).ToString() + "=F";
                            }
                        }
                        else if (fm.Operator == LogicOperator.None)
                        {
                            if (!(fm.Operand(1) is Formula))
                            {
                                val = fm.Operand(1).ToString() + "=T";
                            }
                        }
                    }
                    else
                    {
                        val = fa.Value.ToString() + "=T";
                    }
                    if (!string.IsNullOrEmpty(val))
                    {
                        if (m.Count == 0)
                        {
                            m.Add(val);
                        }
                        else
                        {
                            for (int ix = 0; ix < m.Count; ix++)
                            {
                                if (!m[ix].Contains(val))
                                {
                                    m[ix] += ";" + val;
                                }
                            }
                        }
                    }
                }
                if (_branch.Value != null)
                {
                    return _branch.Value.Models(m);
                }
            }
            return m;
        }

        public override bool Contains(FormulaBase f)
        {
            foreach (KeyValuePair<FormulaOrigin, FormulaBase> fa in _formulas)
            {
                if (fa.Value.Equals(f))
                {
                    return true;
                }
            }
            if (_parent != null)
            {
                if (_parent.Contains(f))
                {
                    return true;
                }
            }
            return false;
        }

        public override bool PerformStep()
        {
            Formula frm = null;
            int ixm = 0;
            for (int ix = 0; ix < _formulas.Count; ix++)
            {
                Formula f = _formulas[ix].Value as Formula;
                if (f != null)
                {
                    if (f.Operator == LogicOperator.And)
                    {
                        StepResult sr = WhatIf(f);
                        if (sr == StepResult.BranchClosed)
                        {
                            ExecuteStep(f, _formulas[ix].Key._fnumber);
                            return true;
                        }
                        else if (sr == StepResult.None)
                        {
                            if (frm == null)
                            {
                                frm = f;
                                ixm = _formulas[ix].Key._fnumber;
                            }
                        }
                    }
                }
            }
            for (int ix = 0; ix < _formulas.Count; ix++)
            {
                Formula f = _formulas[ix].Value as Formula;
                if (f != null)
                {
                    if (f.Operator == LogicOperator.Or)
                    {
                        StepResult sr = WhatIf(f);
                        if (sr == StepResult.BranchClosed)
                        {
                            ExecuteStep(f, _formulas[ix].Key._fnumber);
                            return true;
                        }
                        else if (sr == StepResult.None)
                        {
                            if (frm == null)
                            {
                                frm = f;
                                ixm = _formulas[ix].Key._fnumber;
                            }
                        }
                    }
                }
            }
            if (frm != null)
            {
                ExecuteStep(frm, ixm);
                return true;
            }
            if (_branch.Value != null)
            {
                return _branch.Value.PerformStep();
            }
            return false;
        }

        public override void ExecuteStep(FormulaBase f, int origin)
        {
            if (_branch.Value != null)
            {
                _branch.Value.ExecuteStep(f, origin);
            }
            else
            {
                Formula fm = f as Formula;
                if (fm != null)
                {
                    if (fm.Operator == LogicOperator.And)
                    {
                        _formulas.Add(new KeyValuePair<FormulaOrigin, FormulaBase>(new FormulaOrigin(_fcnt++, origin), fm.Operand(1)));
                        _formulas.Add(new KeyValuePair<FormulaOrigin, FormulaBase>(new FormulaOrigin(_fcnt++, origin), fm.Operand(2)));
                        return;
                    }
                    else if (fm.Operator == LogicOperator.Or)
                    {
                        _branch = new KeyValuePair<int, TableauxElementBeta>(origin, new TableauxElementBeta(this, f));
                        return;
                    }
                }
                throw new ArgumentException();
            }
        }
        public override StepResult WhatIf(FormulaBase f)
        {
            Formula fm = f as Formula;
            if (!Closed)
            {
                if (fm != null)
                {
                    if (_branch.Value != null)
                    {
                        return _branch.Value.WhatIf(f);
                    }
                    if (Contains(fm.Operand(1)) || Contains(fm.Operand(2)))
                    {
                        return StepResult.NotAllowed;
                    }
                    if ((fm.Operator == LogicOperator.And) || (fm.Operator == LogicOperator.Or))
                    {
                        FormulaBase f1 = Negate(fm.Operand(1).Clone());
                        FormulaBase f2 = Negate(fm.Operand(2).Clone());
                        if (Contains(f1) || Contains(f2) || f1.Equals(Negate(f2)))
                        {
                            return StepResult.BranchClosed;
                        }
                        return StepResult.None;
                    }
                }
            }
            return StepResult.NotAllowed;
        }
        public override void Draw(Graphics gr, Font f, RectangleF rb)
        {
            float szw = CalcWidth(gr, f);
            float x = rb.Left + (rb.Width - szw) / 2f;
            float y = rb.Top;
            float hs = 2f + gr.MeasureString("[", f).Height;
            for (int ix = 0; ix < _formulas.Count; ix++)
            {
                KeyValuePair<FormulaOrigin, FormulaBase> frm = _formulas[ix];
                string s = "(" + frm.Key._fnumber.ToString() + ") " + RemoveBrackets(frm.Value.ToString()) + (frm.Key._onumber > 0 ? " [R " + frm.Key._onumber.ToString() + "]" : "");
                gr.DrawString(s, f, Brushes.Black, x, y);
                y += hs;
            }
            if (_branch.Value != null)
            {
                string s = " [R " + _branch.Key.ToString() + "]";
                szw = gr.MeasureString(s, f).Width;
                gr.DrawLine(Pens.Black, rb.Left, y + (hs / 2f), rb.Right - (szw + 4f), y + (hs / 2f));
                gr.DrawString(s, f, Brushes.Black, rb.Right - szw, y);
                rb = new RectangleF(rb.Left, (y + hs), rb.Width, rb.Height);
                rb.Width = rb.Width - (szw + 4f);
                _branch.Value.Draw(gr, f, rb);
            }
            else
            {
                if (Closed)
                {
                    gr.DrawString("#", f, Brushes.Black, x, y);
                }
            }
        }
        public override RectangleF CalcRect(Graphics gr, Font f, RectangleF rb)
        {
            RectangleF rect = new RectangleF(0f, 0f, CalcWidth(gr, f), (gr.MeasureString("[", f).Height + 2f) * (float)_formulas.Count);
            if (_branch.Value != null)
            {
                string s = " [R " + _branch.Key.ToString() + "]";
                SizeF szw = gr.MeasureString(s, f);
                rect = _branch.Value.CalcRect(gr, f, rect);
                rect.Width = rect.Width + szw.Width + 4f;
                rect.Height = rect.Height + szw.Height;
            }
            else
            {
                if (Closed)
                {
                    rect.Height = rect.Height + 2f + gr.MeasureString("#", f).Height;
                }
            }
            return rect;
        }
        private float CalcWidth(Graphics gr, Font f)
        {
            float szw = 0f;
            for (int ix = 0; ix < _formulas.Count; ix++)
            {
                KeyValuePair<FormulaOrigin, FormulaBase> frm = _formulas[ix];
                string s = "(" + frm.Key._fnumber.ToString() + ") " + RemoveBrackets(frm.Value.ToString()) + (frm.Key._onumber > 0 ? " [R " + frm.Key._onumber.ToString() + "]" : "");
                szw = Math.Max(gr.MeasureString(s, f).Width, szw);
            }
            return szw;
        }
    }
}
