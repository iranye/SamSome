﻿using System;
using System.Collections.Generic;
using System.Drawing;
using PLTableauxCalculator.Formulas;

namespace PLTableauxCalculator.Tableaux
{
    public class TableauxElementBeta : TableauxElementBase
    {
        private TableauxElementAlpha _fleft;
        private TableauxElementAlpha _fright;

        public TableauxElementBeta(TableauxElementBase parent, FormulaBase f)
            : base(parent, f)
        {
            Formula fm = f as Formula;
            if (fm.Operator != LogicOperator.Or)
            {
                throw new ArgumentException();
            }
            _fleft = new TableauxElementAlpha(this, fm.Operand(1));
            _fright = new TableauxElementAlpha(this, fm.Operand(2));
        }

        public override bool Closed
        {
            get
            {
                return _fleft.Closed && _fright.Closed;
            }
        }

        public override List<string> Models(List<string> m)
        {
            if (!_fleft.Closed && !_fright.Closed)
            {
                List<string> m2 = new List<string>(m);
                m = _fleft.Models(m);
                m2 = _fright.Models(m2);
                m.AddRange(m2);
            }
            else if (!_fleft.Closed)
            {
                return _fleft.Models(m);
            }
            else if (!_fright.Closed)
            {
                return _fright.Models(m);
            }
            return m;
        }

        public override bool Contains(FormulaBase f)
        {
            if (_parent != null)
            {
                return _parent.Contains(f);
            }
            return false;
        }

        public override bool PerformStep()
        {
            if (_fleft.PerformStep())
            {
                return true;
            }
            return _fright.PerformStep();
        }

        public override void ExecuteStep(FormulaBase f, int origin)
        {
            StepResult srl = _fleft.WhatIf(f);
            if (srl == StepResult.BranchClosed)
            {
                _fleft.ExecuteStep(f, origin);
                return;
            }
            StepResult srr = _fright.WhatIf(f);
            if (srr == StepResult.BranchClosed)
            {
                _fright.ExecuteStep(f, origin);
                return;
            }
            if (srl == StepResult.None)
            {
                _fleft.ExecuteStep(f, origin);
            }
            else if (srr == StepResult.None)
            {
                _fright.ExecuteStep(f, origin);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public override StepResult WhatIf(FormulaBase f)
        {
            StepResult srl = _fleft.WhatIf(f);
            StepResult srr = _fright.WhatIf(f);
            if ((srl == StepResult.BranchClosed) || (srr == StepResult.BranchClosed))
            {
                return StepResult.BranchClosed;
            }
            if ((srl == StepResult.NotAllowed) && (srr == StepResult.NotAllowed))
            {
                return StepResult.NotAllowed;
            }
            return StepResult.None;
        }

        public override void Draw(Graphics gr, Font f, RectangleF rb)
        {
            RectangleF rl = _fleft.CalcRect(gr, f, RectangleF.Empty);
            RectangleF rr = _fright.CalcRect(gr, f, RectangleF.Empty);
            _fleft.Draw(gr, f, new RectangleF(rb.Left, rb.Top, rl.Width, rl.Height));
            _fright.Draw(gr, f, new RectangleF(rb.Right - rr.Width, rb.Top, rr.Width, rr.Height));
        }

        public override RectangleF CalcRect(Graphics gr, Font f, RectangleF rb)
        {
            RectangleF rl = _fleft.CalcRect(gr, f, RectangleF.Empty);
            RectangleF rr = _fright.CalcRect(gr, f, RectangleF.Empty);
            rb.Height = rb.Height + Math.Max(rl.Height, rr.Height);
            rb.Width = rl.Width + rr.Width + rb.Width;
            return rb;
        }
    }
}
