﻿using System;
using System.Collections.Generic;

namespace PLTableauxCalculator.Formulas
{
    public enum LogicOperator
    {
        None, Not, And, Or
    }
    public abstract class FormulaBase : IComparable<FormulaBase>, IEquatable<FormulaBase>
    {
        public const char csnot = (char)172;
        public const char csimp = (char)8594;
        public const char csdimp = (char)8596;
        public const char csand = (char)708;
        public const char csor = (char)709;

        protected static List<FormulaBase> _predicates = new List<FormulaBase>();

        public FormulaBase()
        {
        }

        public static List<FormulaBase> Predicates
        {
            get
            {
                return _predicates;
            }
        }
        public static void Clear()
        {
            _predicates.Clear();
        }
        public abstract LogicOperator Operator { get; }
        public virtual void Negate() { }
        public abstract FormulaBase Operand(int n);
        public abstract FormulaBase Clone();
        public abstract int CompareTo(FormulaBase other);
        public abstract bool Equals(FormulaBase other);
        public virtual string Parse(string expr)
        {
            return expr.TrimStart(new char[] { ' ', '\n', '\r', '\t' });
        }
    }
}
