﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLTableauxCalculator.Formulas
{
    public class Predicate : FormulaBase, IComparable<FormulaBase>, IEquatable<FormulaBase>
    {
        private string _name;

        public Predicate()
            : base()
        {
        }

        public override FormulaBase Operand(int n)
        {
            if (n == 1)
            {
                return this;
            }
            return null;
        }

        public override LogicOperator Operator
        {
            get
            {
                return LogicOperator.None;
            }
        }

        public override FormulaBase Clone()
        {
            return this;
        }

        public override string Parse(string expr)
        {
            string scon = base.Parse(expr);
            if (!string.IsNullOrEmpty(scon))
            {
                if ((char.ToLower(scon[0]) >= 'a') && (char.ToLower(scon[0]) <= 'z'))
                {
                    _name = scon.Substring(0, 1).ToLower();
                    if (scon.Length > 1)
                    {
                        return RPredicate(scon.Substring(1));
                    }
                    if (!FormulaBase._predicates.Contains(this))
                    {
                        FormulaBase._predicates.Add(this);
                    }
                    return "";
                }
            }
            throw new NotRecognizedException();
        }
        public override int CompareTo(FormulaBase other)
        {
            Predicate op = other as Predicate;
            if (op != null)
            {
                return string.Compare(_name, op._name, true);
            }
            return -1;
        }
        public override bool Equals(FormulaBase other)
        {
            Predicate op = other as Predicate;
            if (op != null)
            {
                return string.Compare(_name, op._name, true) == 0;
            }
            else
            {
                return other.Equals(this);
            }
        }
        public override string ToString()
        {
            return _name;
        }
        private string RPredicate(string expr)
        {
            if (char.IsLetterOrDigit(expr, 0))
            {
                _name += expr.Substring(0, 1).ToLower();
                if (expr.Length > 1)
                {
                    return RPredicate(expr.Substring(1));
                }
                expr = "";
            }
            if (!FormulaBase._predicates.Contains(this))
            {
                FormulaBase._predicates.Add(this);
            }
            return expr;
        }
    }
}
