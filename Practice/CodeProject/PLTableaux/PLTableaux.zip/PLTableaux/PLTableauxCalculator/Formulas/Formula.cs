﻿using System;

namespace PLTableauxCalculator.Formulas
{
    public class Formula : FormulaBase, IEquatable<FormulaBase>
    {
        protected FormulaBase _operand1 = null;
        protected FormulaBase _operand2 = null;
        protected LogicOperator _operator = LogicOperator.None;

        public Formula()
            : base()
        {
        }
        public Formula(FormulaBase op1, FormulaBase op2, LogicOperator op)
            : base()
        {
            _operand1 = op1;
            _operand2 = op2;
            _operator = op;
        }

        private string StrOperator
        {
            get
            {
                switch (_operator)
                {
                    case LogicOperator.Not:
                        return csnot.ToString();
                    case LogicOperator.And:
                        return csand.ToString();
                    case LogicOperator.Or:
                        return csor.ToString();
                    default:
                        return "";
                }
            }
        }

        public override FormulaBase Operand(int n)
        {
            if (n == 1)
            {
                return _operand1;
            }
            return _operand2;
        }

        public override LogicOperator Operator
        {
            get
            {
                return _operator;
            }
        }

        public override FormulaBase Clone()
        {
            if (_operand2 != null)
            {
                return new Formula(_operand1.Clone(), _operand2.Clone(), _operator);
            }
            else
            {
                return new Formula(_operand1.Clone(), null, _operator);
            }
        }

        public override void Negate()
        {
            switch (_operator)
            {
                case LogicOperator.None:
                    _operator = LogicOperator.Not;
                    break;
                case LogicOperator.Not:
                    _operator = LogicOperator.None;
                    break;
                case LogicOperator.And:
                    _operand1 = Negate(_operand1);
                    _operand2 = Negate(_operand2);
                    _operator = LogicOperator.Or;
                    break;
                case LogicOperator.Or:
                    _operand1 = Negate(_operand1);
                    _operand2 = Negate(_operand2);
                    _operator = LogicOperator.And;
                    break;
            }
        }

        public override int CompareTo(FormulaBase other)
        {
            throw new NotImplementedException();
        }
        public override bool Equals(FormulaBase other)
        {
            Formula fo = other as Formula;
            if (_operand2 != null)
            {
                if ((fo != null) && (_operator == fo._operator))
                {
                    return ((_operand1.Equals(fo._operand1) && _operand2.Equals(fo._operand2)) || (_operand1.Equals(fo._operand2) && _operand2.Equals(fo._operand1)));
                }
                else
                {
                    return false;
                }
            }
            if (fo != null)
            {
                return _operand1.Equals(fo._operand1) && (_operator == fo._operator);
            }
            else
            {
                return (_operator == LogicOperator.None) && (_operand1.Equals(other));
            }
        }

        public override string Parse(string expr)
        {
            string sexpr = base.Parse(expr);
            if (!string.IsNullOrEmpty(sexpr))
            {
                _operand1 = Formula1(ref sexpr);
                sexpr = base.Parse(sexpr);
                while (!string.IsNullOrEmpty(sexpr))
                {
                    if (sexpr[0] == ')')
                    {
                        break;
                    }
                    else if ((sexpr[0] == csand) || (sexpr[0] == csor))
                    {
                        if (_operand2 != null)
                        {
                            _operand1 = new Formula(_operand1, _operand2, _operator);
                        }
                        _operator = sexpr[0] == csand ? LogicOperator.And : LogicOperator.Or;
                        if (sexpr.Length > 1)
                        {
                            sexpr = base.Parse(sexpr.Substring(1));
                            _operand2 = Formula1(ref sexpr);
                            sexpr = base.Parse(sexpr);
                        }
                        else
                        {
                            throw new BadSyntaxException(sexpr);
                        }
                    }
                    else
                    {
                        throw new BadSyntaxException(sexpr);
                    }
                }
                if ((_operand2 == null) && (_operator != LogicOperator.Not))
                {
                    Formula exp = _operand1 as Formula;
                    if (exp != null)
                    {
                        _operand1 = exp._operand1;
                        _operand2 = exp._operand2;
                        _operator = exp._operator;
                    }
                }
                return sexpr;
            }
            throw new NotRecognizedException();
        }
        private FormulaBase Formula1(ref string expr)
        {
            FormulaBase operand1 = Formula0(ref expr);
            FormulaBase operand2 = null;
            LogicOperator op = LogicOperator.None;
            expr = base.Parse(expr);
            while (!string.IsNullOrEmpty(expr))
            {
                if (expr.StartsWith(csimp.ToString()) || expr.StartsWith(csdimp.ToString()))
                {
                    bool lop = expr.StartsWith(csimp.ToString());
                    if (operand2 != null)
                    {
                        operand1 = new Formula(operand1, operand2, op);
                    }
                    op = expr.StartsWith(csimp.ToString()) ? LogicOperator.Or : LogicOperator.And;
                    int szop = 1;
                    if (expr.Length > szop)
                    {
                        expr = base.Parse(expr.Substring(szop));
                        operand2 = Formula0(ref expr);
                        expr = base.Parse(expr);
                    }
                    else
                    {
                        throw new BadSyntaxException(expr);
                    }
                    if (lop)
                    {
                        operand1 = Negate(operand1);
                    }
                    else
                    {
                        FormulaBase op1c = operand1.Clone();
                        FormulaBase op2c = operand2.Clone();
                        operand1 = Negate(operand1);
                        op2c = Negate(op2c);
                        operand1 = new Formula(operand1, operand2, LogicOperator.Or);
                        operand2 = new Formula(op2c, op1c, LogicOperator.Or);
                    }
                }
                else
                {
                    break;
                }
            }
            if (operand2 != null)
            {
                return new Formula(operand1, operand2, op);
            }
            return operand1;
        }
        private FormulaBase Formula0(ref string expr)
        {
            if (!string.IsNullOrEmpty(expr))
            {
                LogicOperator op = LogicOperator.None;
                while (expr[0] == csnot)
                {
                    op = op == LogicOperator.None ? LogicOperator.Not : LogicOperator.None;
                    if (expr.Length > 1)
                    {
                        expr = expr.Substring(1);
                    }
                    else
                    {
                        throw new BadSyntaxException(expr);
                    }
                }
                if (op == LogicOperator.Not)
                {
                    if (expr.Length > 0)
                    {
                        expr = base.Parse(expr);
                        FormulaBase em = Element(ref expr);
                        expr = base.Parse(expr);
                        if (em is Formula)
                        {
                            em.Negate();
                            return em;
                        }
                        return new Formula(em, null, op);
                    }
                }
                else
                {
                    return Element(ref expr);
                }
            }
            throw new BadSyntaxException(expr);
        }
        private FormulaBase Element(ref string expr)
        {
            if (!string.IsNullOrEmpty(expr))
            {
                try
                {
                    Predicate exp = new Predicate();
                    expr = exp.Parse(expr);
                    return FormulaBase._predicates[FormulaBase._predicates.IndexOf(exp)];
                }
                catch (NotRecognizedException ex)
                {
                }
                if (expr[0] == '(')
                {
                    if (expr.Length > 1)
                    {
                        expr = base.Parse(expr.Substring(1));
                        FormulaBase expar = new Formula();
                        expr = expar.Parse(expr);
                        expr = base.Parse(expr);
                        if (!string.IsNullOrEmpty(expr))
                        {
                            if (expr[0] == ')')
                            {
                                if (expr.Length > 1)
                                {
                                    expr = expr.Substring(1);
                                }
                                else
                                {
                                    expr = "";
                                }
                                return expar;
                            }
                        }
                    }
                }
            }
            throw new BadSyntaxException(expr);
        }

        private FormulaBase Negate(FormulaBase f)
        {
            if (f is Formula)
            {
                f.Negate();
            }
            else
            {
                f = new Formula(f, null, LogicOperator.Not);
            }
            return f;
        }

        public override string ToString()
        {
            if (_operand2 != null)
            {
                return "(" + _operand1.ToString() + StrOperator + _operand2.ToString() + ")";
            }
            return StrOperator + _operand1.ToString();
        }
    }
}
