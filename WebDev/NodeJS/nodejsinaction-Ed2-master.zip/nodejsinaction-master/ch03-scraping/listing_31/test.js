var scraper = require('./index');

scraper.run();
