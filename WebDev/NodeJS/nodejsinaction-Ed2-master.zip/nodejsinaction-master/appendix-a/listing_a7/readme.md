### Multipart example

This example accepts file uploads.

Usage:

```
curl -F file=@index.js http://localhost:3000
```
