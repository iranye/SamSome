### JSON parser example

This example parsers request bodies that contain JSON.

Usage:

```
curl -d '{"name":"tobi"}' -H "Content-Type: application/json" http://localhost:3000
```
