kraken-example
===========

An example Kraken app
