const hello = require('./hello');
const jquery = require('jquery');

hello();
